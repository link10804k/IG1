#include "RGBRectangle.h"

RGBRectangle::RGBRectangle(GLdouble w, GLdouble h) {
	mMesh = Mesh::generateRGBRectangle(w, h);
}

void RGBRectangle::render(glm::mat4 const& modelViewMat) const {
	
	// Cambiamos el modo de dibujado para toda la figura porque no est�n disponibles el FRONT ni el BACK para glPolygonMode
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	EntityWithColors::render(modelViewMat);
	glCullFace(GL_FRONT);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	EntityWithColors::render(modelViewMat);

	glDisable(GL_CULL_FACE);
}